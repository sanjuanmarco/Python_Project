$(document).ready(function(){
    $("#myform").on("submit", function(){
      $("#loader").fadeIn();
    });//submit
});//document ready